 /*!
 * JS FOR ELEGANCE SOCIAL NETWORK
 *
 * @Team author : Smart Xplorer (smartxplorer)
 * @Team author email: smartxplorerdev@gmail.com 
 *************************************************
 * Elegance - The Elegant Social Network Platform
 * Copyright (c) 2017 Elegant. All rights reserved.
 */
 
$(document).ready(function(){
	
	$(".form-first-name").val("First name...");
	$(".form-last-name").val("Last name...");
	$(".form-email").val("Email...");
	$(".form-about-yourself").val("About yourself...");
	
});